import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib
import numpy as np

# Set the global font to be Times New Roman, size 10 (or any other size you want)
matplotlib.rcParams['font.family'] = 'Times New Roman'
matplotlib.rcParams['font.size'] = 12

matplotlib.rcParams['axes.xmargin'] = 0
matplotlib.rcParams['axes.ymargin'] = 0

# Read the CSV data
# data = pd.read_csv('/home/naga/klab_ws/src/test/csv/l1_-1.3_-10_1.csv',encoding = 'UTF8')
data = pd.read_csv('/home/naga/klab_ws/src/test/s1/s1_1_2-12-6.csv',encoding = 'UTF8')
t = data['time']
# plt.plot(t.to_numpy(),data['Velocity_r100'].to_numpy(),label='R100')
# plt.plot(t.to_numpy(),data['Velocity_maxon'].to_numpy(),label='R100')
# data['Velocity_r100'].plot(x=data['time'])
# data['Velocity_maxon'].plot(x=data['time'])
# (-data['output_vel']).plot(x=data['time'])

# Create a subplot with 3 rows and 1 column
fig, ax = plt.subplots(figsize=(8.0, 4.0))

# Generate time data starting from 0.25s
t_alternating = np.arange(0.25, t.max(), 0.5)

# Generate alternating +5 and -5 data
alternating_data = np.tile([5, -5], len(t_alternating) // 2)

# If t_alternating is longer
if len(t_alternating) > len(alternating_data):
    t_alternating = t_alternating[:len(alternating_data)]

# If alternating_data is longer
elif len(alternating_data) > len(t_alternating):
    alternating_data = alternating_data[:len(t_alternating)]

# Plot the alternating data
ax.plot(t_alternating, alternating_data, label='alternating', color='purple')

# Plot 'Velocity_maxon' on the second subplot
# Plot 'Velocity_r100'
ax.plot(t.to_numpy(), data['Velocity_r100'].to_numpy(), label='motor1', color='red')

# Plot 'Velocity_maxon'
ax.plot(t.to_numpy(), (-data['Velocity_maxon']/6).to_numpy(), label='motor2', color='blue')

# Plot 'output_vel'
ax.plot(t.to_numpy(), (-data['output_vel']).to_numpy(), label='output', color=(0.1, 0.8, 0.1))

# ax.axvline(x=5, color='black', linestyle=':')
# ax.axvline(x=10, color='black', linestyle=':')

# Set labels and ticks
ax.set_xlabel('Time [s]')  # Set the x-axis label to 'Time'
ax.set_ylabel('Velocity [rad/s]')  # Set the y-axis label to 'Velocity'
ax.tick_params(direction='in')  
ax.set_ylim([-15, 15]) 
ax.set_xlim([0, 7]) 

# Set legend
lines, labels = ax.get_legend_handles_labels()
ax.legend(lines, labels, loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=3, frameon=False)

plt.show()

plt.show()